const { FlashbotsBundleProvider } = require('@flashbots/ethers-provider-bundle');
const { ethers } = require('ethers');

class FlashbotsManager {
    constructor(wallet, provider) {
        this.wallet = wallet;
        this.provider = provider;
        this.flashbotsProvider = null;
    }

    /**
     * Initialize the Flashbots provider.
     * Requires a separate auth signer (can be a random wallet) to identify the searcher.
     */
    async init() {
        const authSigner = ethers.Wallet.createRandom();
        this.flashbotsProvider = await FlashbotsBundleProvider.create(
            this.provider,
            authSigner,
            "https://relay.flashbots.net", // Mainnet Relay
            "mainnet"
        );
        console.log("Flashbots Provider initialized.");
    }

    /**
     * Send a bundle of transactions to Flashbots.
     * @param {Array} signedTxs - Array of signed transaction strings.
     * @param {number} targetBlock - The block number to target.
     */
    async sendBundle(signedTxs, targetBlock) {
        if (!this.flashbotsProvider) {
            throw new Error("Flashbots provider not initialized.");
        }

        const bundleSubmission = await this.flashbotsProvider.sendRawBundle(
            signedTxs,
            targetBlock
        );

        if ('error' in bundleSubmission) {
            console.error("Flashbots Bundle Error:", bundleSubmission.error.message);
            return { success: false, error: bundleSubmission.error.message };
        }

        const waitResponse = await bundleSubmission.wait();
        console.log(`Flashbots Bundle Status: ${FlashbotsBundleProvider.getBundleStatus(waitResponse)}`);
        
        return {
            success: waitResponse === 0, // 0 = Included, 1 = NotIncluded, 2 = AccountNonceTooHigh
            status: FlashbotsBundleProvider.getBundleStatus(waitResponse)
        };
    }

    /**
     * Simulate a bundle before sending.
     */
    async simulateBundle(signedTxs, targetBlock) {
        const simulation = await this.flashbotsProvider.simulate(signedTxs, targetBlock);
        if ('error' in simulation) {
            console.error("Flashbots Simulation Error:", simulation.error.message);
            return { success: false, error: simulation.error.message };
        }
        console.log("Flashbots Simulation Success!");
        return { success: true, simulation };
    }
}

module.exports = FlashbotsManager;
