const client = require('prom-client');
const express = require('express');

class MonitoringSystem {
    constructor(port = 9090) {
        this.port = port;
        this.app = express();
        this.register = new client.Registry();

        // Define metrics
        this.arbitrageOpportunities = new client.Counter({
            name: 'mev_arbitrage_opportunities_total',
            help: 'Total number of arbitrage opportunities detected',
            labelNames: ['dex1', 'dex2']
        });

        this.successfulTrades = new client.Counter({
            name: 'mev_successful_trades_total',
            help: 'Total number of successful arbitrage trades'
        });

        this.profitTotal = new client.Gauge({
            name: 'mev_profit_total_eth',
            help: 'Total profit accumulated in ETH'
        });

        this.gasSpent = new client.Gauge({
            name: 'mev_gas_spent_total_eth',
            help: 'Total gas spent in ETH'
        });

        this.register.registerMetric(this.arbitrageOpportunities);
        this.register.registerMetric(this.successfulTrades);
        this.register.registerMetric(this.profitTotal);
        this.register.registerMetric(this.gasSpent);

        this.setupServer();
    }

    setupServer() {
        this.app.get('/metrics', async (req, res) => {
            res.set('Content-Type', this.register.contentType);
            res.end(await this.register.metrics());
        });

        this.app.listen(this.port, () => {
            console.log(`Monitoring server listening on port ${this.port}`);
        });
    }

    recordOpportunity(dex1, dex2) {
        this.arbitrageOpportunities.inc({ dex1, dex2 });
    }

    recordSuccess(profit, gas) {
        this.successfulTrades.inc();
        this.profitTotal.inc(profit);
        this.gasSpent.inc(gas);
    }
}

module.exports = MonitoringSystem;
