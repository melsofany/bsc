const { ethers } = require('ethers');

class PriceFeeds {
    constructor(provider) {
        this.provider = provider;
        this.prices = {};
    }

    async getReserves(poolAddress) {
        const abi = [
            "function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast)"
        ];
        const contract = new ethers.Contract(poolAddress, abi, this.provider);
        try {
            const [reserve0, reserve1] = await contract.getReserves();
            return { reserve0, reserve1 };
        } catch (error) {
            console.error(`Error fetching reserves for ${poolAddress}:`, error);
            return null;
        }
    }

    async updatePrices(pools) {
        for (const pool of pools) {
            const reserves = await this.getReserves(pool.address);
            if (reserves) {
                this.prices[pool.name] = reserves;
                console.log(`Updated price for ${pool.name}: ${reserves.reserve0} / ${reserves.reserve1}`);
            }
        }
    }
}

module.exports = PriceFeeds;
