const { ethers } = require('ethers');

class ArbitrageDetector {
    constructor(priceFeeds) {
        this.priceFeeds = priceFeeds;
    }

    async checkArbitrage(tokenA, tokenB, dex1, dex2) {
        const price1 = await this.priceFeeds.getReserves(dex1.poolAddress);
        const price2 = await this.priceFeeds.getReserves(dex2.poolAddress);

        if (!price1 || !price2) return null;

        // Simplified price calculation (reserve1 / reserve0)
        const p1 = Number(price1.reserve1) / Number(price1.reserve0);
        const p2 = Number(price2.reserve1) / Number(price2.reserve0);

        const spread = Math.abs(p1 - p2) / Math.min(p1, p2);
        console.log(`Spread between ${dex1.name} and ${dex2.name}: ${(spread * 100).toFixed(4)}%`);

        if (spread > 0.005) { // 0.5% spread threshold
            console.log("Arbitrage Opportunity Found!");
            return {
                buyOn: p1 < p2 ? dex1 : dex2,
                sellOn: p1 < p2 ? dex2 : dex1,
                spread: spread
            };
        }
        return null;
    }
}

module.exports = ArbitrageDetector;
