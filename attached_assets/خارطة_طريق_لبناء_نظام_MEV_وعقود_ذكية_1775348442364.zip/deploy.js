const hre = require("hardhat");

async function main() {
  console.log("Deploying Arbitrage Contract...");

  const Arbitrage = await hre.ethers.getContractFactory("Arbitrage");
  const arbitrage = await Arbitrage.deploy();

  await arbitrage.waitForDeployment();

  console.log(`Arbitrage Contract deployed to: ${await arbitrage.getAddress()}`);
  console.log("Save this address to your .env file as ARBITRAGE_CONTRACT");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
