const { ethers } = require('ethers');
const PQueue = require('p-queue').default;
require('dotenv').config();

const MempoolListener = require('./src/listeners/mempool');
const PriceFeeds = require('./src/listeners/price_feeds');
const ArbitrageDetector = require('./src/strategies/arbitrage_detector');
const MEVSearcher = require('./src/strategies/mev_searcher');
const TxBuilder = require('./src/execution/tx_builder');
const GasOptimizer = require('./src/execution/gas_optimizer');
const TransactionSimulator = require('./src/execution/simulator');
const FlashbotsManager = require('./src/execution/flashbots_provider');
const MonitoringSystem = require('./src/monitoring/metrics');
const logger = require('./utils/logger');

async function main() {
    logger.info("Initializing Production MEV Arbitrage Bot...");

    // 1. Setup Provider and Wallet
    const provider = new ethers.JsonRpcProvider(process.env.RPC_URL);
    const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);

    // 2. Initialize Components
    const monitoring = new MonitoringSystem(process.env.MONITORING_PORT);
    const priceFeeds = new PriceFeeds(provider);
    const detector = new ArbitrageDetector(priceFeeds);
    const searcher = new MEVSearcher(provider);
    const txBuilder = new TxBuilder(wallet, provider);
    const gasOptimizer = new GasOptimizer(provider);
    const simulator = new TransactionSimulator(provider);
    const flashbots = new FlashbotsManager(wallet, provider);
    const mempool = new MempoolListener(process.env.WSS_URL);

    // Initialize Flashbots
    await flashbots.init();

    // 3. Concurrency Queue for processing opportunities
    const queue = new PQueue({ concurrency: 5 });

    // 4. Start Monitoring
    logger.info("Bot is running and monitoring for opportunities...");

    // Listen for Mempool Transactions
    mempool.listen();

    // Periodic Price Check (Every 10 seconds)
    setInterval(async () => {
        try {
            const pools = [
                { name: "Uniswap V2 WETH/USDC", address: "0xB4e16d0168e52d35CaCD2c6185b44281Ec28C9Dc" },
                { name: "Sushiswap WETH/USDC", address: "0x397FF1542f962076d0BFE58eA045FfA2d347ACa0" }
            ];
            await priceFeeds.updatePrices(pools);

            const opportunity = await detector.checkArbitrage(
                "WETH", "USDC",
                { name: "Uniswap", poolAddress: pools[0].address },
                { name: "Sushiswap", poolAddress: pools[1].address }
            );

            if (opportunity) {
                monitoring.recordOpportunity(opportunity.buyOn.name, opportunity.sellOn.name);
                
                // Add to queue for simulation and execution
                queue.add(async () => {
                    logger.info(`Processing opportunity: ${opportunity.buyOn.name} -> ${opportunity.sellOn.name}`);
                    
                    // Build Transaction
                    const tx = await txBuilder.buildArbitrageTx(process.env.ARBITRAGE_CONTRACT, {
                        router1: opportunity.buyOn.poolAddress,
                        router2: opportunity.sellOn.poolAddress,
                        token1: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2", // WETH
                        token2: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", // USDC
                        amountIn: ethers.parseEther("1.0")
                    });

                    // Simulate
                    const simResult = await simulator.simulate(tx);
                    if (simResult.success) {
                        logger.info("Simulation successful, sending to Flashbots...");
                        
                        // Sign and Send via Flashbots
                        const signedTx = await wallet.signTransaction(tx);
                        const targetBlock = await provider.getBlockNumber() + 1;
                        const bundleResult = await flashbots.sendBundle([signedTx], targetBlock);
                        
                        if (bundleResult.success) {
                            logger.info("Bundle included in block!");
                            monitoring.recordSuccess(0.01, 0.005); // Placeholder values
                        }
                    } else {
                        logger.warn(`Simulation failed: ${simResult.error}`);
                    }
                });
            }
        } catch (error) {
            logger.error(`Error in main loop: ${error.message}`);
        }
    }, 10000);
}

main().catch((error) => {
    logger.error(`Fatal error: ${error.message}`);
    process.exit(1);
});
