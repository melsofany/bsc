// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

interface IERC20 {
    function transfer(address recipient, uint256 amount) external returns (bool);
    function approve(address spender, uint256 amount) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
}

interface IUniswapV2Router {
    function swapExactTokensForTokens(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external returns (uint[] memory amounts);
}

contract Arbitrage {
    address public owner;

    constructor() {
        owner = msg.sender;
    }

    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }

    function executeArbitrage(
        address router1,
        address router2,
        address token1,
        address token2,
        uint256 amountIn
    ) external onlyOwner {
        uint256 startBalance = IERC20(token1).balanceOf(address(this));
        
        // Step 1: Swap token1 for token2 on router1
        IERC20(token1).approve(router1, amountIn);
        address[] memory path1 = new address[](2);
        path1[0] = token1;
        path1[1] = token2;
        IUniswapV2Router(router1).swapExactTokensForTokens(
            amountIn,
            0,
            path1,
            address(this),
            block.timestamp
        );

        // Step 2: Swap token2 for token1 on router2
        uint256 token2Balance = IERC20(token2).balanceOf(address(this));
        IERC20(token2).approve(router2, token2Balance);
        address[] memory path2 = new address[](2);
        path2[0] = token2;
        path2[1] = token1;
        IUniswapV2Router(router2).swapExactTokensForTokens(
            token2Balance,
            0,
            path2,
            address(this),
            block.timestamp
        );

        uint256 endBalance = IERC20(token1).balanceOf(address(this));
        require(endBalance > startBalance, "Arbitrage failed: No profit");
    }

    function withdraw(address token) external onlyOwner {
        uint256 balance = IERC20(token).balanceOf(address(this));
        IERC20(token).transfer(owner, balance);
    }
}
