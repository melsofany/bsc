const { ethers } = require('ethers');
require('dotenv').config();

class MempoolListener {
    constructor(providerUrl) {
        this.provider = new ethers.WebSocketProvider(providerUrl);
    }

    async listen() {
        console.log("Starting Mempool Listener...");
        this.provider.on("pending", async (txHash) => {
            try {
                const tx = await this.provider.getTransaction(txHash);
                if (tx && tx.to) {
                    this.analyzeTransaction(tx);
                }
            } catch (error) {
                // Ignore errors for missing transactions (already mined or dropped)
            }
        });
    }

    analyzeTransaction(tx) {
        // Filter for DEX interactions (e.g., Uniswap V2/V3)
        // This is a placeholder for actual DEX signature filtering
        const dexAddresses = [
            "0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D", // Uniswap V2 Router
            "0xE592427A0AEce92De3Edee1F18E0157C05861564"  // Uniswap V3 Router
        ];

        if (dexAddresses.includes(tx.to.toLowerCase())) {
            console.log(`Potential MEV Opportunity: ${tx.hash}`);
            // Emit event or call strategy detector
        }
    }
}

module.exports = MempoolListener;
