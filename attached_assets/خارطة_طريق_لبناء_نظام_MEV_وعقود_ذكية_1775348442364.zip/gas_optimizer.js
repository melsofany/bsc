const { ethers } = require('ethers');

class GasOptimizer {
    constructor(provider) {
        this.provider = provider;
    }

    async getOptimalGasPrice() {
        const feeData = await this.provider.getFeeData();
        const baseFee = feeData.lastBaseFeePerGas;
        const priorityFee = feeData.maxPriorityFeePerGas;

        // Add a 10% buffer for MEV transactions to ensure inclusion
        const optimalMaxFee = (baseFee * 110n) / 100n + priorityFee;
        const optimalPriorityFee = (priorityFee * 120n) / 100n;

        console.log(`Optimal Gas Price: MaxFee=${ethers.formatUnits(optimalMaxFee, 'gwei')} Gwei, PriorityFee=${ethers.formatUnits(optimalPriorityFee, 'gwei')} Gwei`);

        return {
            maxFeePerGas: optimalMaxFee,
            maxPriorityFeePerGas: optimalPriorityFee
        };
    }

    async estimateGasLimit(tx) {
        try {
            const gasLimit = await this.provider.estimateGas(tx);
            // Add 20% buffer for complex smart contract logic
            return (gasLimit * 120n) / 100n;
        } catch (error) {
            console.error("Gas estimation failed:", error);
            return 500000n; // Default fallback
        }
    }
}

module.exports = GasOptimizer;
